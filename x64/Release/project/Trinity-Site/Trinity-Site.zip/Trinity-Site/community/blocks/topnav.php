<?php

/*
 * Twisted Trinity
 * twistedtrinity.org
 * topnav.php
 * found in /blocks/
 *
 * Copyright Scott Cilley scott@twedev.com
 * Twisted Development
 * www.twedev.com
*/
?>

<ul>
  <li><a href="/">Home</a></li>
  <li><a href="#">Community</a></li>
  <li><a href="#"></a></li>
  <li><a href="#"></a></li>
</ul>