<?php

/*
 * Twisted Trinity
 * twistedtrinity.org
 * footer.php
 * found in /includes/
 *
 * Copyright Scott Cilley scott@twedev.com
 * Twisted Development
 * www.twedev.com
*/

// end the content div
echo '<!-- end the content div -->';
echo '</div>';

// include the right block
echo '<!-- include the right block -->';
include 'blocks/right-block.php';
?>


<!-- End the Wrapper -->
</div>

<!-- The Footer -->
<div id="footer">
  <p class="copyright">Copyright &copy; <?php echo date("Y");?> | Twisted Trinity</p>
</div>

</body>
</html>