<?php

/*
 * Twisted Trinity
 * twistedtrinity.org
 * index.php
 * found in /commuinity
 *
 * Copyright Scott Cilley scott@twedev.com
 * Twisted Development
 * www.twedev.com
*/

// include the header
include 'includes/header.php';

/* Content only below the ?>
 * use the <div></div>
 * content div is closed in the footer
 * for universal usage
*/
?>

<div class="post">
  <h2>COMMUNITY</h2>
  <p>This platform will be available soon.</p>
</div>


<?php
// include the footer
include 'includes/footer.php';
?>