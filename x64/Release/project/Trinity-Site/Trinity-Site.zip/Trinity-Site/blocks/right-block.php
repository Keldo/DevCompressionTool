<?php

/*
 * Twisted Trinity
 * twistedtrinity.org
 * right-block.php
 * found in /blocks/
 *
 * Copyright Scott Cilley scott@twedev.com
 * Twisted Development
 * www.twedev.com
*/
?>

<div id="right">
  <?php 
    include 'blocks/realms.php';
	include 'blocks/bug-status.php';
	include 'blocks/connect.php';
?>
</div>