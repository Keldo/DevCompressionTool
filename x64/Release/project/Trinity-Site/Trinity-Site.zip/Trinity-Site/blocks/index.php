<?php

include ('../includes/functions.php');
redirect_to("/");
?>

