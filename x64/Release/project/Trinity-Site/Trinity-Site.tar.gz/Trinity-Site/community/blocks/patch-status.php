<?php

/*
 * Twisted Trinity
 * twistedtrinity.org
 * patch-status.php
 * found in /blocks/
 *
 * Copyright Scott Cilley scott@twedev.com
 * Twisted Development
 * www.twedev.com
*/

?>

<h2>Patch Status</h2>
<ul>
  <li>#6xG001W - 100% Completed</li>
</ul>