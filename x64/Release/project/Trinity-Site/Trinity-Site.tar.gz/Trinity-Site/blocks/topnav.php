<?php

/*
 * Twisted Trinity
 * twistedtrinity.org
 * topnav.php
 * found in /blocks/
 *
 * Copyright Scott Cilley scott@twedev.com
 * Twisted Development
 * www.twedev.com
*/
?>

<ul>
  <li><a href="/">Home</a></li>
  <li><a href="/bugtracker.php">Current Bugs</a></li>
  <li><a href="/connect.php">How to Connect</a></li>
  <li><a href="/patch.php">Patch Status</a></li>
  <li><a href="/create.php">Sign Up</a></li>
</ul>