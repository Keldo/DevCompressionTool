<?php

/*
 * Twisted Trinity
 * twistedtrinity.org
 * patch-status.php
 * found in /blocks/
 *
 * Copyright Scott Cilley scott@twedev.com
 * Twisted Development
 * www.twedev.com
*/

?>

<h2>Connect</h2>
<ul>
  <li>set portal = "logon.twistedtrinity.org"</li>
</ul>