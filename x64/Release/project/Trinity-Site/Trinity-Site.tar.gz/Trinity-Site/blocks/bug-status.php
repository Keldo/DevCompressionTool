<?php

/*
 * Twisted Trinity
 * twistedtrinity.org
 * patch-status.php
 * found in /blocks/
 *
 * Copyright Scott Cilley scott@twedev.com
 * Twisted Development
 * www.twedev.com
*/

?>

<h2>Bug Status</h2>
<ul>
  <li><a href="patch.php">#6x001</a> - 100% Completed</li>
  <li><a href="patch.php">#6x002</a> - 100% Completed</li>
  <li><a href="patch.php">#6x006</a> - <strong>Updated</strong></li>
</ul>