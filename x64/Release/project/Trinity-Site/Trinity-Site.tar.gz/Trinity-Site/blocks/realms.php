<h2>Realm Status</h2>
<?php


g6status();

realmStatus();

?>